# Django project `base` — Deployment notes

This repository contains a minimal Django project configured to run on Render.com (free tier).

Key points
- Static files are served by WhiteNoise (configured in `base/settings.py`).
- Media files (user uploads) are stored in the project `media/` folder and will be served by Django. NOTE: on free hosts (including Render free tier) the filesystem is ephemeral — uploads will not persist across deploys/restarts.
- The `requirements.txt` includes `Django`, `whitenoise`, and `gunicorn`.

Quick local setup

1. Create and activate your virtualenv (PowerShell):

```powershell
python -m venv venv
.\venv\Scripts\Activate.ps1
```

2. Install dependencies and collect static files:

```powershell
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
python manage.py collectstatic --noinput
```

3. Run the development server:

```powershell
python manage.py runserver
```

Deploying to Render

Render will install dependencies listed in `requirements.txt`. Use these recommended settings for a Python web service:

- Build Command:

```bash
pip install -r requirements.txt && python manage.py collectstatic --noinput
```

- Start Command:

```bash
gunicorn base.wsgi:application --bind 0.0.0.0:$PORT --workers 3
```

Environment variables (set these in Render's dashboard under Environment):

- `SECRET_KEY` — your Django secret key (keep private).
- `DJANGO_DEBUG` — set to `False` in production to disable debug.
- `ALLOWED_HOSTS` — a comma-separated list of allowed hosts (e.g. `your-app.onrender.com`).

Notes and recommendations

- Because media is stored in the local filesystem in this configuration, uploaded files will be lost on deploys/restarts on free tiers. If you need persistence later, switch to object storage (S3 or Render object storage) and configure `django-storages`.
- WhiteNoise handles static file serving and compression; ensure `python manage.py collectstatic --noinput` runs during deployment.
- Do not commit your real `SECRET_KEY` into the repository. Use environment variables or Render's secret management.

Troubleshooting

- If `collectstatic` fails due to missing files referenced in templates or CSS, check `STATICFILES_DIRS` and referenced paths. You can switch `STATICFILES_STORAGE` to a non-manifest storage temporarily if needed.

Contact / Next steps

If you want, I can:
- Add Render-specific `render.yaml` for infrastructure-as-code.
- Add `django-storages` S3 config and optional code-paths to use it when env vars are set.

---
Generated on: 2025-11-01
