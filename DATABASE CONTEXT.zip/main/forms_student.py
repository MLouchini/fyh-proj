from django import forms


class HomeworkCodeForm(forms.Form):
    code = forms.CharField(max_length=64, label='Homework Code')


class StudentSubmissionForm(forms.Form):
    student_name = forms.CharField(max_length=255, required=False)
    uploaded_file = forms.FileField(required=False)
    # recorded_video will be attached via JS as 'recorded_video'
