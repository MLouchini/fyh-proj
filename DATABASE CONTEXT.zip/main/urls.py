from django.urls import path
from . import views

app_name = 'main'

urlpatterns = [
    path('', views.home, name='home'),
    path('teacher/', views.teacher_menu, name='teacher_menu'),
    path('teacher/set/', views.set_homework, name='set_homework'),
    path('teacher/set/success/<int:pk>/', views.set_success, name='set_success'),
    path('student/', views.student_entry, name='student_entry'),
    path('student/load/', views.student_load, name='student_load'),
    path('student/submit/<int:pk>/', views.student_submit, name='student_submit'),
    path('student/interview/<int:submission_id>/', views.student_interview, name='student_interview'),
    path('student/interview/<int:submission_id>/answer/<int:qindex>/', views.student_answer, name='student_answer'),
    path('student/interview/<int:submission_id>/complete/', views.student_interview_complete, name='student_interview_complete'),
]
