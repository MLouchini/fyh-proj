from django.db import models
import uuid
import os
from django.utils import timezone


def homework_upload_to(instance, filename):
    """Store uploads under homework_files/<homework.id>/ and name files as <HOMEWORK_CODE>_<n>.<ext>

    The index n is 1-based and equals existing attachments for the homework + 1.
    """
    base, ext = os.path.splitext(filename)
    hw = instance.homework
    try:
        existing = HomeworkAttachment.objects.filter(homework=hw).count()
    except Exception:
        existing = 0
    index = existing + 1
    new_filename = f"{hw.code}_{index}{ext}"
    return f'homework_files/{hw.id}/{new_filename}'


class Homework(models.Model):
    title = models.CharField(max_length=255)
    subject = models.CharField(max_length=100, blank=True)
    level = models.CharField(max_length=100, blank=True)
    class_group = models.CharField(max_length=255, blank=True)
    due_date = models.DateField(null=True, blank=True)
    total_marks = models.PositiveIntegerField(null=True, blank=True)
    num_questions = models.PositiveIntegerField(null=True, blank=True)
    instructions = models.TextField(blank=True)
    code = models.CharField(max_length=64, unique=True, default='')
    created_at = models.DateTimeField(default=timezone.now)

    def save(self, *args, **kwargs):
        if not self.code:
            # simple code generator: HW-YYYY-XXXX
            year = timezone.now().year
            rand = uuid.uuid4().hex[:6].upper()
            self.code = f'HW-{year}-{rand}'
        super().save(*args, **kwargs)

    def __str__(self):
        return f"{self.title} ({self.code})"


class HomeworkAttachment(models.Model):
    homework = models.ForeignKey(Homework, on_delete=models.CASCADE, related_name='attachments')
    file = models.FileField(upload_to=homework_upload_to)
    label = models.CharField(max_length=100, blank=True)

    def __str__(self):
        return f"Attachment for {self.homework.code}: {self.file.name}"
 

class HomeworkSubmission(models.Model):
    homework = models.ForeignKey(Homework, on_delete=models.CASCADE, related_name='submissions')
    student_name = models.CharField(max_length=255, blank=True)
    uploaded_file = models.FileField(upload_to='submissions/', null=True, blank=True)
    recorded_video = models.FileField(upload_to='submissions/videos/', null=True, blank=True)
    processed_result = models.TextField(blank=True)
    created_at = models.DateTimeField(default=timezone.now)

    def __str__(self):
        return f"Submission {self.id} for {self.homework.code}"


class InterviewQuestion(models.Model):
    submission = models.ForeignKey(HomeworkSubmission, on_delete=models.CASCADE, related_name='interview_questions')
    index = models.PositiveIntegerField()
    question_text = models.TextField()
    recording = models.FileField(upload_to='interview_answers/', null=True, blank=True)
    answered = models.BooleanField(default=False)
    created_at = models.DateTimeField(default=timezone.now)

    class Meta:
        unique_together = (('submission', 'index'),)
        ordering = ['index']

    def __str__(self):
        return f"Q{self.index} for submission {self.submission.id}"

