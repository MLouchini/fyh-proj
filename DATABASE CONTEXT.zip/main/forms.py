from django import forms
from .models import Homework


class HomeworkForm(forms.ModelForm):
    due_date = forms.DateField(widget=forms.DateInput(attrs={'type': 'date'}), required=False)
    class Meta:
        model = Homework
        fields = ['title', 'subject', 'level', 'class_group', 'due_date', 'total_marks', 'num_questions', 'instructions']


class UploadFilesForm(forms.Form):
    questions = forms.FileField(required=True)
    mark_scheme = forms.FileField(required=True)
    model_answers = forms.FileField(required=False)
    textbook = forms.FileField(required=False)
