from django.shortcuts import render, redirect
from django.http import HttpResponseRedirect
from django.urls import reverse
from .forms import HomeworkForm, UploadFilesForm
from .forms_student import HomeworkCodeForm, StudentSubmissionForm
from .models import Homework, HomeworkAttachment, HomeworkSubmission
from django.conf import settings
import os

# external APIs
import openai
from huggingface_hub import InferenceClient


def home(request):
    """Render the techy home page with teacher and student buttons."""
    return render(request, 'main/home.html')


def teacher_menu(request):
    return render(request, 'main/teacher_menu.html')


def set_homework(request):
    if request.method == 'POST':
        form = HomeworkForm(request.POST)
        files_form = UploadFilesForm(request.POST, request.FILES)
        if form.is_valid() and files_form.is_valid():
            hw = form.save()
            # Required files
            questions = files_form.cleaned_data.get('questions')
            mark_scheme = files_form.cleaned_data.get('mark_scheme')
            if questions:
                HomeworkAttachment.objects.create(homework=hw, file=questions, label='questions')
            if mark_scheme:
                HomeworkAttachment.objects.create(homework=hw, file=mark_scheme, label='mark_scheme')
            # Optional
            model_answers = files_form.cleaned_data.get('model_answers')
            textbook = files_form.cleaned_data.get('textbook')
            if model_answers:
                HomeworkAttachment.objects.create(homework=hw, file=model_answers, label='model_answers')
            if textbook:
                HomeworkAttachment.objects.create(homework=hw, file=textbook, label='textbook')
            return redirect('main:set_success', pk=hw.pk)
    else:
        form = HomeworkForm()
        files_form = UploadFilesForm()
    return render(request, 'main/set_homework.html', {'form': form, 'files_form': files_form})


def set_success(request, pk):
    hw = Homework.objects.filter(pk=pk).first()
    if not hw:
        return redirect('main:teacher_menu')
    return render(request, 'main/set_success.html', {'homework': hw})


def student_entry(request):
    form = HomeworkCodeForm(request.POST or None)
    if request.method == 'POST' and form.is_valid():
        code = form.cleaned_data['code']
        redirect_url = reverse('main:student_load') + f'?code={code}'
        return HttpResponseRedirect(redirect_url)
    return render(request, 'main/student_entry.html', {'form': form})


def student_load(request):
    code = request.GET.get('code') or request.POST.get('code')
    hw = None
    if code:
        hw = Homework.objects.filter(code__iexact=code.strip()).first()
    return render(request, 'main/student_load.html', {'homework': hw, 'code': code})


def _init_hf_inference():
    token = os.getenv('HUGGINGFACE_API_KEY') or getattr(settings, 'HUGGINGFACE_API_KEY', None)
    if not token:
        return None
    # instantiate InferenceClient (you can change model when calling)
    return InferenceClient(token=token)


def _init_openai():
    key = os.getenv('OPENAI_API_KEY') or getattr(settings, 'OPENAI_API_KEY', None)
    if not key:
        return None
    openai.api_key = key
    return openai


def student_submit(request, pk):
    hw = Homework.objects.filter(pk=pk).first()
    if not hw:
        return redirect('main:student_entry')

    if request.method == 'POST':
        form = StudentSubmissionForm(request.POST, request.FILES)
        if form.is_valid():
            sub = HomeworkSubmission.objects.create(
                homework=hw,
                student_name=form.cleaned_data.get('student_name', ''),
                uploaded_file=request.FILES.get('uploaded_file')
            )
            # if recorded video sent via 'recorded_video'
            recorded = request.FILES.get('recorded_video')
            if recorded:
                sub.recorded_video = recorded
                sub.save()

            # Process using Hugging Face inference (example: generate interview questions)
            hf = _init_hf_inference()
            interview_prompts = []
            if hf:
                try:
                    prompt = f"Generate 3 short interview questions for students based on this homework title: {hw.title}. Keep them concise."
                    # use the InferenceClient to call a text-generation model
                    try:
                        res = hf.text_generation(model='google/flan-t5-large', inputs=prompt)
                    except Exception:
                        # fallback to generic call
                        res = hf(inputs=prompt, model='google/flan-t5-large')
                    # Normalize response: could be dict, list, or string
                    text = ''
                    if isinstance(res, dict):
                        text = res.get('generated_text') or res.get('text') or ''
                    elif isinstance(res, list) and len(res) > 0:
                        # list of generations
                        first = res[0]
                        if isinstance(first, dict):
                            text = first.get('generated_text') or first.get('text') or ''
                        else:
                            text = str(first)
                    else:
                        text = str(res)
                    interview_prompts = (text or '').split('\n')[:3]
                except Exception:
                    interview_prompts = []

            # Use OpenAI to craft more specific interview stages/questions
            openai_client = _init_openai()
            llm_questions = []
            if openai_client:
                try:
                    messages = [
                        {"role": "system", "content": "You are an assistant that generates short interview questions for students based on a homework description."},
                        {"role": "user", "content": f"Homework title: {hw.title}\nInstructions: {hw.instructions}\nGenerate 3 concise interview questions."}
                    ]
                    resp = openai_client.ChatCompletion.create(model='gpt-3.5-turbo', messages=messages, max_tokens=200)
                    out = resp['choices'][0]['message']['content']
                    llm_questions = out.split('\n')[:3]
                except Exception:
                    llm_questions = []

            # Store processed result and create per-question InterviewQuestion entries
            combined = '\n'.join([*interview_prompts, *llm_questions])
            sub.processed_result = combined
            sub.save()
            questions = [q for q in ([*interview_prompts] + [*llm_questions]) if q]
            # create InterviewQuestion rows
            from .models import InterviewQuestion
            for i, qtext in enumerate(questions, start=1):
                InterviewQuestion.objects.create(submission=sub, index=i, question_text=qtext)

            return redirect('main:student_interview', submission_id=sub.id)
    else:
        form = StudentSubmissionForm()
    return render(request, 'main/student_submit.html', {'form': form, 'homework': hw})


def student_interview(request, submission_id):
    sub = HomeworkSubmission.objects.filter(pk=submission_id).first()
    if not sub:
        return redirect('main:student_entry')
    # find first unanswered question or use query param
    qparam = request.GET.get('q')
    questions_qs = sub.interview_questions.all().order_by('index')
    if not questions_qs.exists():
        # nothing to interview on
        return redirect('main:student_interview_complete', submission_id=sub.id)
    if qparam:
        try:
            qindex = int(qparam)
        except Exception:
            qindex = 1
    else:
        next_q = questions_qs.filter(answered=False).first()
        qindex = next_q.index if next_q else questions_qs.last().index

    question = questions_qs.filter(index=qindex).first()
    total = questions_qs.count()
    is_last = (qindex == total)
    return render(request, 'main/student_interview.html', {'submission': sub, 'question': question, 'qindex': qindex, 'total': total, 'is_last': is_last})


def student_answer(request, submission_id, qindex):
    # Accept POST with 'answer_video' file and save to InterviewQuestion.recording
    sub = HomeworkSubmission.objects.filter(pk=submission_id).first()
    if not sub:
        return redirect('main:student_entry')
    from .models import InterviewQuestion
    q = InterviewQuestion.objects.filter(submission=sub, index=qindex).first()
    if not q:
        return redirect('main:student_interview', submission_id=sub.id)
    if request.method == 'POST':
        f = request.FILES.get('answer_video')
        if f:
            q.recording = f
            q.answered = True
            q.save()
        # determine next question
        nxt = InterviewQuestion.objects.filter(submission=sub, answered=False).order_by('index').first()
        if nxt:
            # Return only the fragment the client expects (#interview-root) so the SPA can replace it
            context = {
                'submission': sub,
                'question': nxt,
                'qindex': nxt.index,
                'total': InterviewQuestion.objects.filter(submission=sub).count(),
                'is_last': (nxt.index == InterviewQuestion.objects.filter(submission=sub).count()),
            }
            return render(request, 'main/_interview_fragment.html', context)
        else:
            # Interview finished: return the completion page HTML so the client can replace the document
            return render(request, 'main/student_interview_complete.html', {'submission': sub})
    # only allow POST
    return redirect('main:student_interview', submission_id=sub.id)


def student_interview_complete(request, submission_id):
    sub = HomeworkSubmission.objects.filter(pk=submission_id).first()
    if not sub:
        return redirect('main:student_entry')
    return render(request, 'main/student_interview_complete.html', {'submission': sub})
