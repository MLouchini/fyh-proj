(function(){
  const toggle = document.getElementById('theme-toggle');
  const root = document.documentElement;

  // Initialize theme from localStorage or prefers-color-scheme
  function initTheme(){
    const saved = localStorage.getItem('theme');
    if(saved){
      root.classList.toggle('light', saved === 'light');
      if(toggle) toggle.textContent = saved === 'light' ? '🌙' : '☀️';
      return;
    }
    const prefersLight = window.matchMedia && window.matchMedia('(prefers-color-scheme: light)').matches;
    root.classList.toggle('light', prefersLight);
    if(toggle) toggle.textContent = prefersLight ? '🌙' : '☀️';
  }

  function flip(){
    const isLight = root.classList.toggle('light');
    localStorage.setItem('theme', isLight ? 'light' : 'dark');
    toggle.textContent = isLight ? '🌙' : '☀️';
  }

  if(toggle){
    toggle.addEventListener('click', flip);
  }

  // small button click ripple animation
  function ripple(e){
    const target = e.currentTarget;
    const circle = document.createElement('span');
    circle.className = 'ripple';
    const rect = target.getBoundingClientRect();
    const size = Math.max(rect.width, rect.height);
    circle.style.width = circle.style.height = size + 'px';
    circle.style.left = (e.clientX - rect.left - size/2) + 'px';
    circle.style.top = (e.clientY - rect.top - size/2) + 'px';
    target.appendChild(circle);
    setTimeout(()=> circle.remove(),600);
  }

  document.querySelectorAll('.role-btn').forEach(btn => {
    btn.addEventListener('click', (e)=>{
      const href = btn.getAttribute('href');
      ripple(e);
      // simple feedback animation
      setTimeout(()=>{
        btn.classList.add('clicked');
        setTimeout(()=>btn.classList.remove('clicked'),600);
      },120);

      // If the link points to a real href (not '#'), delay navigation slightly so animation can be seen.
      if(href && href !== '#' && !href.startsWith('javascript:')){
        e.preventDefault();
        setTimeout(()=>{ window.location.assign(href); }, 160);
      }else{
        // otherwise prevent default (it's a placeholder) so nothing happens
        e.preventDefault();
      }
    })
  })

  initTheme();
})();
